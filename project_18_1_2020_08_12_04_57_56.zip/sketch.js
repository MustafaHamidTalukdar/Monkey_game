var monkey,img1,monkeyover,img2;
var jungle,img3;

var bananaGroup,img4,img5;
var stoneGroup,img6;

var invisibleGround;
function preload(){
img1 = loadAnimation("Monkey1.png","Monkey2.png","Monkey3.png","Monkey4.png","Monkey5.png","Monkey6.png","Monkey7.png","Monkey8.png","Monkey9.png","Monkey10.png");
img2 = loadImage("Monkey.png");
  
img3 = loadImage("jungle2.jpg");  

img4 = loadImage("Banana.png");
  
img6 = loadImage("stone.png");
}

function setup() {
  
  createCanvas(600, 300);
  
  monkey = createSprite(140,30);
  monkey.loadAnimation("play",img1);
  
  monkeyover = createSprite(140,30);
  monkey.addImage("over",img2);
  
  jungle = createSprite(300,150);
  jungle.addImage("jungle",img3);
  jungle.x = jungle.width /2;
  jungle.velocityX = -2;
  
  invisibleGround = createSprite(10,10,400,10);
  invisibleGround.visible = false;
  
  bananaGroup = new Group();
  stoneGroup = new Group();
  
}

function draw() {
  background(220);
  
  if(keyDown("space")) {
    monkey.velocityY = -10;
  }
  
  monkey.velocityY = monkey.velocityY + 0.8;
  
  
  if (jungle.x < 0){
    jungle.x = jungle.width/2;
    monkey.collide(invisibleGround);
    
   spawnbanana();
   spawnstone();
    
  drawSprites();
  }
}

function spawnbanana() {
  if (frameCount % 60 === 0) {
    var banana = createSprite(600,320,40,10);
    cloud.y = Math.round(random(80,120));
    banana.addImage("banana",img4);
    banana.scale = 0.5;
    banana.velocityX = -3;
    
    banana.lifetime = 200;
    
    //adjust the depth
    banana.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
    spawnbanana.add(banana);
  }
  
}

function spawnstone() {
  if(frameCount % 60 === 0) {
    var stone = createSprite(200,180,10,40);
    stone.velocityX = -6;
        
    stone.scale = 0.5;
    stone.lifetime = 70;
  }
}